class HowLongToBeatEntry:
    def __init__(self,detailId,gameName,description,playableOn,imageUrl,timeLabels,gameplayMain,gameplayMainExtra,gameplayCompletionist):
        self.detailId = detailId
        self.gameName = gameName
        self.description = description
        self.playableOn = playableOn
        self.imageUrl = imageUrl
        self.timeLabels = timeLabels
        self.gameplayMain = gameplayMain
        self.gameplayMainExtra = gameplayMainExtra
        self.gameplayCompletionist = gameplayCompletionist
        
