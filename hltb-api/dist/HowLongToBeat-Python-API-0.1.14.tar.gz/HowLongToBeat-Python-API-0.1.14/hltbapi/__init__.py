from .HowLongToBeatEntry import HowLongToBeatEntry
from .HtmlScraper import HtmlScraper