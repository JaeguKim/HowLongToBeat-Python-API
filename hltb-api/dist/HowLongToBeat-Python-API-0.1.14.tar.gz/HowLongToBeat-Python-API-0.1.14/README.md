# Example Package
You can easily search play-time of specific game you want to know by using this package.   
You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)